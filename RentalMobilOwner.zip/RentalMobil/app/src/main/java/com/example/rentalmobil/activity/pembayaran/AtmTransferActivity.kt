package com.example.rentalmobil.activity.pembayaran

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.core.content.ContextCompat
import com.example.rentalmobil.R
import com.example.rentalmobil.`class`.Converter
import kotlinx.android.synthetic.main.activity_atm_transfer.*
import kotlinx.android.synthetic.main.activity_atm_transfer.toolbar_tracking
import kotlinx.android.synthetic.main.activity_detail_tracking.*

class AtmTransferActivity : AppCompatActivity() {
//    var id = 0L
//    var area = ""
//    var driver = ""
//    var datePickReturn = ""
//    var total = 0
//    var emailUser = ""
//    var idUser = ""
    val convert = Converter()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_atm_transfer)

        setSupportActionBar(toolbar_tracking)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        supportActionBar?.title = "Transfer Atm"
        toolbar_tracking.setTitleTextColor(ContextCompat.getColor(this, R.color.colorWhite))

        var id = intent.getLongExtra("id",0L)
        var nameCar = intent.getStringExtra("nameCar")
        var year = intent.getStringExtra("year")
        var color = intent.getStringExtra("color")
        var area = intent.getStringExtra("area")
        var driver = intent.getStringExtra("driver")
        var datePickReturn = intent.getStringExtra("datePickReturn")
        var emailUser = intent.getStringExtra("emailUser")
//        Log.e("_emailUser", emailUser)
        var idUser = intent.getStringExtra("idUser")
        var total = intent.getIntExtra("total", 0)
        tv_price_bri.text = "Rp ${convert.rupiahFormat(total.toString())}"


        btn_confirm_atm.setOnClickListener {
            val intent = Intent(this, ConfiirmPaymentAtmActivity::class.java)
            intent.putExtra("idCar", id)
            intent.putExtra("area", area)
            intent.putExtra("driver", driver)
            intent.putExtra("datePickReturn", datePickReturn)
            intent.putExtra("emailUser", emailUser)
            intent.putExtra("idUser", idUser)
            intent.putExtra("total", total)
            intent.putExtra("nameCar", nameCar)
            intent.putExtra("year", year)
            intent.putExtra("color", color)
            startActivity(intent)
        }



    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        onBackPressed()
        return super.onOptionsItemSelected(item)
    }
}