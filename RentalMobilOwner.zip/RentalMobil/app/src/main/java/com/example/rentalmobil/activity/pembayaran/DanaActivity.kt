package com.example.rentalmobil.activity.pembayaran

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.rentalmobil.R

class DanaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dana)


    }
}