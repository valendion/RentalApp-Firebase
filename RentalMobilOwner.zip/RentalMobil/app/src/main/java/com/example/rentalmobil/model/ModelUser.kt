package com.example.rentalmobil.model


data class ModelUser (
    var email: String,
    var id: Long,
    var no_hp: String,
    var password: String,
    var status: String
)