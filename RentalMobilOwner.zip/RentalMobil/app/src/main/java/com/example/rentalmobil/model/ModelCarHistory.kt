package com.example.rentalmobil.model

data class ModelCarHistory(
    var merek: String,
    var tahun: String,
    var warna: String
)