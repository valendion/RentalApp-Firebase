package com.example.rentalmobil.activity.home

import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.rentalmobil.R
import com.example.rentalmobil.`class`.Converter
import com.google.android.gms.maps.GoogleMap
import kotlinx.android.synthetic.main.activity_detail_tracking.*

class DetailTrackingActivity : AppCompatActivity() {
    val convert = Converter()
    lateinit var imageCar: String
    lateinit var nameCar: String
    lateinit var colorCar: String
    lateinit var yearCar: String
    lateinit var platCar: String
    lateinit var kodeTracking: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_tracking)

        imageCar = intent.getStringExtra("imageCar")
        nameCar = intent.getStringExtra("merek")
        colorCar = intent.getStringExtra("warna")
        yearCar = intent.getStringExtra("tahun")
        platCar = intent.getStringExtra("plat")
        kodeTracking = intent.getStringExtra("kodetracking")

        setSupportActionBar(toolbar_tracking)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        supportActionBar?.title = "Detail Tracking"
        toolbar_tracking.setTitleTextColor(ContextCompat.getColor(this, R.color.colorWhite))

        convert.imageLoader(imageCar,iv_image_car_tracking)
        tv_name_car_confirm.text = nameCar
        tv_plat_tracking.text = platCar
        tv_name_car_confirm.text = nameCar
        tv_color_confirm.text = colorCar
        tv_year_confirm.text = yearCar

        var link = "<iframe width=\"100%\" height=\"100%\" src=$kodeTracking</iframe>"
        wv_tracking_car.settings.javaScriptEnabled = true
        wv_tracking_car.loadData(link, "text/html", "utf-8")


    }




}
