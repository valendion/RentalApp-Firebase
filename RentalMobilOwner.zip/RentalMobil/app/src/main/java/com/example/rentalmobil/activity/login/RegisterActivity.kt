package com.example.rentalmobil.activity.login

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.Gravity
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.rentalmobil.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.android.synthetic.main.activity_register.*


class RegisterActivity : AppCompatActivity() {

    lateinit var mAut: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        mAut = FirebaseAuth.getInstance()



        btn_register.setOnClickListener {

            var email = et_email_register.editText?.text.toString().trim()
            var pass = et_password_register.editText?.text.toString().trim()

            if (email.isEmpty()) {
                val toast = Toast.makeText(this, "Masukkan email anda", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.CENTER, 0, 0)
                toast.show()

            } else if (!validEmail(email)) {
                val toast = Toast.makeText(this, "Masukkan format dengan benar", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.CENTER, 0, 0)
                toast.show()

            } else if (pass.isEmpty()) {
                val toast = Toast.makeText(this, "Masukkan password anda", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.CENTER, 0, 0)
                toast.show()
            } else if (pass.length < 6) {
                val toast = Toast.makeText(this, "Password terlalu pendek", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.CENTER, 0, 0)
                toast.show()
            } else {

                mAut.createUserWithEmailAndPassword(email, pass)
                    .addOnCompleteListener {
                        if (it.isSuccessful) {
                            var user = mAut.currentUser
                            val toast =
                                Toast.makeText(this, "Register berhasil", Toast.LENGTH_SHORT)
                            toast.setGravity(Gravity.CENTER, 0, 0)
                            toast.show()
                            startActivity(Intent(this, LoginActivity::class.java))
                            finish()
                        } else {
                            val toast = Toast.makeText(this, "Register gagal", Toast.LENGTH_SHORT)
                            toast.setGravity(Gravity.CENTER, 0, 0)
                            toast.show()
                        }
                    }
            }
        }

    }

    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser: FirebaseUser? = mAut.currentUser
    }

    fun validEmail(email: String): Boolean{
        var pattern = Patterns.EMAIL_ADDRESS
        return pattern.matcher(email).matches()
    }
}