package com.example.rentalmobil.model

data class ModelCar (
    var id: Long = 0L,
    var url: String = "",
    var hargadalamkota: String = "",
    var hargaluarkota: String = "",
    var merek: String = "",
    var tahun: String = "",
    var warna: String = "",
    var plat: String = "",
    var fasilitas1: String = "",
    var fasilitas2: String = "",
    var fasilitas3: String = "",
    var fasilitas4: String = "",
    var fasilitas5: String = "",
)