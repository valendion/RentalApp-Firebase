package com.example.rentalmobil.model

data class ModelGambar(
    var imageName: String,
    var imageUrl: String
)